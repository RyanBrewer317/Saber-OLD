module Grammar where
import Text.Parsec (SourcePos)

data Syntax = SVar !String
            | SInt !Int
            | SLam !String !STerm
            | SApp !STerm !STerm
            | SLet !String !STerm !STerm
            deriving (Show)

type STerm = Located Syntax

data Located a = Loc { val :: !a, start :: !SourcePos } deriving (Show)

data Term = Var !String !Int
          | IntLit !Int
          | Lam !String !Int !(Located Term)
          | App !(Located Term) !(Located Term)
          | Let !String !Int !(Located Term) !(Located Term)
          deriving (Show)

data ANFVal = ANFVar !Int
            | ANFInt !Int
            | ANFGlob !Int

data ANFTerm = ANFHalt !ANFVal
             | ANFFunc !Int ![Int] !ANFTerm !ANFTerm
             | ANFJoin !Int !(Maybe Int) !ANFTerm !ANFTerm
             | ANFJump !Int !(Maybe Int)
             | ANFApp !Int !Int ![ANFVal] !ANFTerm
             | ANFTuple !Int ![ANFVal] !ANFTerm
             | ANFProj !Int !Int !Int !ANFTerm

type ANFJoin = (Int, Maybe Int, ANFTerm)
type ANFFunc = (Int, [Int], ANFJoin, [ANFJoin])

type DiffList a = [a] -> [a]
